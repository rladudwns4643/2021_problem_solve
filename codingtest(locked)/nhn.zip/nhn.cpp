#include <iostream>
/*
//1
#include <vector>
#include <set>
using namespace std;

bool checkSame(const set<int>& a, const set<int>& b) {
    set<int> t;
    for (const auto& c : a) t.insert(c);
    for (const auto& c : b) t.insert(c);
    if (t.size() > 9) return false;
    return true;
}

bool checkBefore(const set<int>& beforeCard, const set<int>& nowCard) {
    if (beforeCard.size() == 0) return false;
    set<int> t;
    for (const auto& c : beforeCard) t.insert(c);
    for (const auto& c : nowCard) t.insert(c);
    if (t.size() > 8) return false;
    return true;
}

bool checkProblem(const set<int>& ba, const set<int>& bb, const set<int>& a, const set<int>& b) {
    if (checkBefore(ba, a) == true) return true;
    if (checkBefore(bb, b) == true) return true;
    if (checkSame(a, b) == true) return true;
    return false;
}

int solution(vector<vector<int>> cards1, vector<vector<int>> cards2) {
    int answer{ 0 };
    set<int> beforeCard_a, beforeCard_b;
    for (int i = 0; i < cards1.size(); ++i) {
        set<int> nowCard_a, nowCard_b;
        for (int j = 0; j < 5; ++j) {
            nowCard_a.insert(cards1[i][j]);
            nowCard_b.insert(cards2[i][j]);
        }
        if (checkProblem(beforeCard_a, beforeCard_b, nowCard_a, nowCard_b) == true) answer++;
        beforeCard_a = nowCard_a;
        beforeCard_b = nowCard_b;
    }
    return answer;
}

int main() {
    auto a = solution(
        { {21, 21, 24, 29, 50} },
        { {5, 10, 15, 41, 49} }
    );
    cout << a;
}
*/

/*
//2
#include <string>
#include <vector>
#include <stack>
using namespace std;
typedef int COST;
typedef int OWNER;
typedef pair<OWNER, COST> poc;
vector<stack<poc>> table;
vector<int> answer;

void give(int from, int to, int cost) {
    while (1) {
        poc f = table[from].top();
        if (f.second > cost) {
            table[from].pop();
            table[from].push({ f.first, f.second - cost });
            table[to].push({ f.first, cost });
            return;
        }
        else if (f.second == cost) {
            table[from].pop();
            table[to].push({ f.first, cost });
            return;
        }
        else if (f.second < cost) {
            table[from].pop();
            table[to].push({ f.first, f.second });
            cost -= f.second;
        }
    }
}

void calc(const vector<int>& abnormal) {
    for (int i = 0; i < table.size(); ++i) {
        while (!table[i].empty()) {
            poc t = table[i].top();
            bool isbad{ false };
            for (int j = 0; j < abnormal.size(); ++j) {
                if (t.first == (abnormal[j]-1)) isbad = true;
            }
            if(isbad == false) answer[i] += t.second;
            table[i].pop();
        }
    }
}

vector<int> solution(vector<int> balance, vector<vector<int>> transaction, vector<int> abnormal) {
    answer.resize(balance.size());
    table.resize(balance.size());
    for (int i = 0; i < balance.size(); ++i) {
        table[i].push({ i, balance[i] });
    }

    for (int i = 0; i < transaction.size(); ++i) {
        give(transaction[i][0] - 1, transaction[i][1] - 1, transaction[i][2]);
    }

    calc(abnormal);

    return answer;
}

int main() {
    solution(
        { 100,1,1,1,1 },
        { {1, 2, 100},{2, 3, 101},{3, 4, 102},{4, 5, 103},{5, 1, 104} },
        { 1 });
}
*/

/*
//3
#include <string>
#include <vector>
#include <sstream>
#include <queue>
#include <set>
using namespace std;
string table[101];//[y][x]
typedef pair<int, int> pii;
pii dir[4] = { {1,0}, {-1,0}, {0,-1}, {0,1} };
int maxX;
int maxY;
bool checkOut(int y, int x) {
    return (x >= 0 && x < maxX) && (y >= 0 && y < maxY);
}

int bfs(int by, int bx, int ey, int ex, string moveable) {
    int check[101][101];
    bool checktable[101][101];
    fill(&checktable[0][0], &checktable[100][101], false);
    fill(&check[0][0], &check[100][101], 0);
    
    set<char> able;
    for (const auto& a : moveable) {
        able.insert(a);
    }

    for (int i = 0; i < maxY; ++i) {
        for (int j = 0; j < maxX; ++j) {
            if (able.find(table[i][j]) != able.end()) {
                checktable[i][j] = true;
            }
        }
    }

    int cx = bx, cy = by;
    queue<pii> q;
    q.push({ cy, cx });
    check[cy][cx] = 1;


    while (!q.empty()) {
        cy = q.front().first;
        cx = q.front().second;
        q.pop();

        if (ey == cy && ex == cx) break;

        for (int i = 0; i < 4; ++i) {
            int ny = cy + dir[i].first;
            int nx = cx + dir[i].second;

            if (!checkOut(ny, nx)) continue;
            if (check[ny][nx] == 0 && checktable[ny][nx] == true) {
                check[ny][nx] = check[cy][cx] + 1;
                q.push({ ny,nx });
            }
        }
    }

    if (check[ey][ex] == 0) return -1;
    return check[ey][ex];
}


vector<int> solution(vector<string> maze, vector<string> queries) {
    vector<int> answer;
    maxX = maze[0].size();
    maxY = maze.size();
    for (int i = 0; i < maxY; ++i) {
        table[i] = maze[i];
    }
    for (int i = 0; i < queries.size(); ++i) {
        stringstream ss;
        ss.str(queries[i]);
        int bx, by, ex, ey;
        string able;
        ss >> by >> bx >> ey >> ex >> able;
        answer.emplace_back(bfs(by-1, bx-1, ey-1, ex-1, able));
    }
    return answer;
}

int main() {
    solution({ "AAA", "ABB", "ABA" },
        { "1 1 1 3 A", "1 3 3 1 A", "1 1 3 3 A", "1 1 3 3 AB" });
}
*/